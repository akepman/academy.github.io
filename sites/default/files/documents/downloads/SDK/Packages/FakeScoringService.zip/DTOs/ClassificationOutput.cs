﻿namespace Terrasoft.ML.Interfaces
{
	using System;
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: ClassificationOutput

	/// <summary>
	/// Represents the output from classification algorithm.
	/// </summary>
	[CollectionDataContract]
	public class ClassificationOutput : List<ClassificationResult>
	{
	}

	#endregion

	#region Class: ClassificationResult

	/// <summary>
	/// Represent result for single class in the machine learning or statistical classification problem.
	/// </summary>
	[DataContract]
	[System.Diagnostics.DebuggerDisplay("Value = {Value}; Significance = {Significance}; Probability = {Probability}")]
	public class ClassificationResult
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets the name of the associated class.
		/// </summary>
		[DataMember(Name = "Value")]
		public string Value { get; set; }

		private double _value;

		/// <summary>
		/// Gets or sets the probability value.
		/// </summary>
		[DataMember(Name = "Probability")]
		public double Probability {
			get {
				return _value;
			}
			set {
				if (value < 0.0 || 1.0 < value) {
					throw new ArgumentException("Probability is expected to be a number between 0 and 1");
				}
				_value = value;
			}
		}

		/// <summary>
		/// Gets or set significance code of given category within classification task.
		/// </summary>
		[DataMember(Name = "Significance")]
		public string Significance { get; set; }

		#endregion

	}

	#endregion

}
