﻿namespace Terrasoft.ML.Interfaces.Responses
{
	using System;
	using System.Runtime.Serialization;

	#region Class: StartSessionResponse

	/// <summary>
	/// Represents response for <see cref="Requests.StartSessionRequest"/>.
	/// </summary>
	[DataContract]
	public class StartSessionResponse
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets scheduled session identifier.
		/// </summary>
		[DataMember(Name = "sessionId", IsRequired = true)]
		public Guid SessionId { get; set; }

		#endregion

	}

	#endregion

}
