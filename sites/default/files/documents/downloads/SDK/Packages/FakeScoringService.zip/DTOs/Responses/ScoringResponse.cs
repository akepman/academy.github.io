﻿namespace Terrasoft.ML.Interfaces.Responses
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: ScoringResponse

	/// <summary>
	/// Represents response from machine learning scoring service.
	/// </summary>
	[DataContract]
	public class ScoringResponse
	{

		#region Properties: Public

		/// <summary>
		/// The collection of scoring outputs - one output item per each input item.
		/// </summary>
		[DataMember(Name = "outputs")]
		public List<ScoringOutput> Outputs { get; set; }

		#endregion

	}

	#endregion

}
