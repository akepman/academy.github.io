﻿namespace Terrasoft.ML.Interfaces
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: DatasetValue

	/// <summary>
	/// Represents row in dataset.
	/// </summary>
	[DataContract]
	public class DatasetValue : Dictionary<string, object> 
	{
	}

	#endregion

	#region Class: DatasetInput

	/// <summary>
	/// Input contract for dataset-based predictions.
	/// </summary>
	[DataContract]
	public class DatasetInput : PredictionInput
	{

		#region Properties: Public

		/// <summary>
		/// Dataset for prediction.
		/// </summary>
		[DataMember(Name = "dt")]
		public IList<DatasetValue> Data { get; set; }

		#endregion

	}

	#endregion

}
