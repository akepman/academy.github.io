﻿namespace Terrasoft.ML.Interfaces
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: RecommendationInput

	/// <summary>
	/// Input data contract for recommendation prediction.
	/// </summary>
	public class RecommendationInput : PredictionInput
	{

		#region Properties: Public

		/// <summary>
		/// Identifiers of users, who will receive a recommendation.
		/// </summary>
		[DataMember(Name ="userIds")]
		public List<string> UserIds { get; set; }

		/// <summary>
		/// Items to filter out or use in prediction, depending on <see cref="FilterItemsMode"/>.
		/// </summary>
		[DataMember(Name = "filterItems")]
		public List<string> FilterItems { get; set; }

		/// <summary>
		/// Defines filter mode. White means to use only specified <see cref="FilterItems"/> in
		/// prediction, black means to filter out <see cref="FilterItems"/> from prediction list.
		/// </summary>
		[DataMember(Name = "filterItemsMode")]
		public string FilterItemsMode { get; set; }

		/// <summary>
		/// Filter out already interacted items on prediction calculation.
		/// </summary>
		[DataMember(Name = "filterAlreadyInteractedItems")]
		public bool FilterAlreadyInteractedItems { get; set; }

		/// <summary>
		/// Quantity of items to recommend to user.
		/// </summary>
		[DataMember(Name = "predictionRecordsCount")]
		public int PredictionRecordsCount { get; set; }

		/// <summary>
		/// Data for new user items
		/// </summary>
		[DataMember(Name = "userItems")]
		public List<DatasetValue> UserItems { get; set; }

		/// <summary>
		/// Recalculate user recommendations, using information from <see cref="UserItems"/>
		/// </summary>
		[DataMember(Name = "recalculateUsers")]
		public bool RecalculateUsers { get; set; }

		#endregion

	}

	#endregion

}
