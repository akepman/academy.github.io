﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System.Runtime.Serialization;

	#region Class: ClassificationRequest

	/// <summary>
	/// Represents request to machine learning classification service.
	/// </summary>
	[DataContract]
	public class ClassificationRequest : PredictionRequest<DatasetInput>
	{
	}

	#endregion

}
