﻿namespace Terrasoft.ML.Interfaces
{
	using System;
	using System.Runtime.Serialization;

	#region Class: ClassificationInput

	/// <summary>
	/// Represents the input for classification algorithm.
	/// </summary>
	[DataContract]
	[Obsolete("7.12.3 | Use Terrasoft.ML.Interfaces.PredictionInput instead.")]
	public class ClassificationInput : PredictionInput
	{
	}

	#endregion

}
