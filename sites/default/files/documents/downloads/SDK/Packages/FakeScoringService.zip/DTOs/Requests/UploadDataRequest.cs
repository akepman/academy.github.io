﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System;
	using System.Runtime.Serialization;

	#region Class: UploadDataRequest

	/// <summary>
	/// Represent service request for uploading training data.
	/// </summary>
	[DataContract]
	public class UploadDataRequest
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets training session identifier.
		/// </summary>
		[DataMember(Name = "sessionId", IsRequired = true)]
		public Guid SessionId { get; set; }

		/// <summary>
		/// Serialized data chunk.
		/// </summary>
		[DataMember(Name = "data", IsRequired = true)]
		public string Data { get; set; }

		#endregion

	}

	#endregion

}
