﻿namespace Terrasoft.ML.Interfaces
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: RecommendedItem

	/// <summary>
	/// Describes recommendation result for single item.
	/// </summary>
	[DataContract]
	[System.Diagnostics.DebuggerDisplay("ItemId = {ItemId}; Score = {Score}")]
	public class RecommendedItem
	{

		#region Properties: Public

		/// <summary>
		/// Identifier of item.
		/// </summary>
		[DataMember(Name = "item_id")]
		public string ItemId { get; set; }

		/// <summary>
		/// Prediction relevance score.
		/// </summary>
		[DataMember(Name = "score")]
		public double Score { get; set; }

		#endregion

	}

	#endregion

	#region Class: RecommendationOutput

	/// <summary>
	/// Describes recommendations for single user.
	/// </summary>
	[DataContract]
	[System.Diagnostics.DebuggerDisplay("UserId = {UserId}; Items = {Items}")]
	public class RecommendationOutput
	{

		#region Properties: Public

		/// <summary>
		/// User, who receives recommendation.
		/// </summary>
		[DataMember(Name = "user_id")]
		public string UserId { get; set; }

		/// <summary>
		/// Recommended items for user.
		/// </summary>
		[DataMember(Name = "items")]
		public List<RecommendedItem> Items { get; set; }

		#endregion

	}

	#endregion

}
