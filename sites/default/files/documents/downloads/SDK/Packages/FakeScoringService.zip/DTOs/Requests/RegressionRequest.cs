﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System.Runtime.Serialization;

	#region Class: RegressionRequest

	/// <inheritdoc />
	/// <summary>
	/// Represents numeric prediction request to machine learning service.
	/// </summary>
	[DataContract]
	public class RegressionRequest : PredictionRequest<DatasetInput>
	{
	}

	#endregion

}
