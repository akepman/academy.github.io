exec DBMS_UTILITY.compile_schema('YOUR_SCHEMA_NAME');
commit;

exit;