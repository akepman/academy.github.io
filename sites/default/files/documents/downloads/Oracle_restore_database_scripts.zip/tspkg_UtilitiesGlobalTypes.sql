/*
** Project: BPMonline
** DBMS   : Oracle
** Type   : Package
** Name   : tspkg_UtilitiesGlobalTypes
*/
drop type "type_GetAdminUnitListObjTable";
drop type "type_GetAdminUnitListObject";

CREATE OR REPLACE TYPE "type_GetAdminUnitListObject" IS OBJECT (
     "Id"     VARCHAR2(38 BYTE),
     "Name"     NVARCHAR2(250),
     "ParentRoleId"   VARCHAR2(38 BYTE)
);
/

CREATE OR REPLACE TYPE "type_GetAdminUnitListObjTable" AS TABLE OF "type_GetAdminUnitListObject";
/

DROP TYPE "type_GetResForSchemaObjTable";
DROP TYPE "type_GetResForSchemaObject";

CREATE TYPE "type_GetResForSchemaObject" IS OBJECT (
        "Level" INT,
        "Culture" NVARCHAR2(250),
        "Data"   BLOB);
/

CREATE TYPE "type_GetResForSchemaObjTable" IS TABLE OF "type_GetResForSchemaObject";
/

DROP TYPE "type_GetResForAllSchemasObjTab";
DROP TYPE "type_GetResForAllSchemasObject";

CREATE TYPE "type_GetResForAllSchemasObject" IS OBJECT (
        "Id"     VARCHAR2(38 BYTE),
        "Name" NVARCHAR2(250),
        "Level" INT,
        "Culture" NVARCHAR2(250),
        "Data"   BLOB);
/

CREATE TYPE "type_GetResForAllSchemasObjTab" IS TABLE OF "type_GetResForAllSchemasObject";
/

DROP TYPE "type_SplitStringTable";
DROP TYPE "type_SplitStringObject";

CREATE TYPE "type_SplitStringObject" IS OBJECT ("Item" VARCHAR2(250 CHAR));
/

CREATE TYPE "type_SplitStringTable" IS TABLE OF "type_SplitStringObject";
/

DROP TYPE "type_GetRolesListObjTable";
DROP TYPE "type_GetRolesListObject";

CREATE OR REPLACE TYPE "type_GetRolesListObject" IS OBJECT (
     "Id"     VARCHAR2(38 BYTE),
     "ParentRoleId"   VARCHAR2(38 BYTE),
     "SysAdminUnitTypeValue" INTEGER
);
/

CREATE OR REPLACE TYPE "type_GetRolesListObjTable" AS TABLE OF "type_GetRolesListObject";
/

DROP TYPE "type_GetSchemaHierachyObjTable";
DROP TYPE "type_GetSchemaHierachyObject";

CREATE OR REPLACE TYPE "type_GetSchemaHierachyObject" IS OBJECT (
     "Id"     VARCHAR2(38 BYTE),
     "SysSchemaId"     VARCHAR2(38 BYTE),
     "Name"   NVARCHAR2(250),
     "ParentId" VARCHAR2(38 BYTE),
     "Level" INT
);
/

CREATE OR REPLACE TYPE "type_GetSchemaHierachyObjTable" AS TABLE OF "type_GetSchemaHierachyObject";
/

CREATE OR REPLACE TYPE "type_RecordPositionObjTable" AS TABLE OF integer;
/

DROP TYPE "type_RecordPositionObjTable";

CREATE OR REPLACE TYPE "type_RecordPositionObject" IS Object (
	"Id"		varchar2(38 BYTE) NULL,
	"Position"	integer NULL,
	"Priority"	integer NULL);
/

CREATE OR REPLACE TYPE "type_RecordPositionObjTable" AS TABLE OF "type_RecordPositionObject";
/
exit;
